import random
import pygame
import math

f = open("HighScore1.txt",'r+')
highestscore=int(f.read())
f.seek(0)
flag=0

pygame.init()

background = pygame.image.load('SpaceBackground.png')

screen = pygame.display.set_mode((800, 600))

pygame.display.set_caption("Space Invaders")
icon = pygame.image.load('spaceship.png')
pygame.display.set_icon(icon)

playerimg = pygame.image.load('player.png')
playerspeed= 5
playerX = 350
playerY = 480
PchangeX = 0
PchangeY = 0

enemyimg = pygame.image.load('red.png')
enemyX = random.randint(0, 735)
enemyY = random.randint(0, 150)
enemyspeed = 1
EchangeX = enemyspeed
EchangeY = 40

# ready - you cant see the bullet
# fire - the bullet is current moving
bulletimg = pygame.image.load('bullet.png')
bulletX = 0
bulletY = 480
BchangeX = 0
BchangeY = 10
bullet_state = "ready"

score = 0
font=pygame.font.Font('freesansbold.ttf',32)
textX=10
textY=10

over_font=pygame.font.Font('freesansbold.ttf',60)

cfont= pygame.font.Font('freesansbold.ttf', 14)

hsfont= pygame.font.Font('freesansbold.ttf', 20)

def showscore(x,y):
    score_value=font.render("Level : "+str(score),True,(255,255,255))
    screen.blit(score_value,(x,y))

def highscore():
    hs_value=hsfont.render("Highest Level Reached : "+str(highestscore),True,(255,255,255))
    screen.blit(hs_value,(530,10))

def congrats():
    congrats = font.render("Congratulations you are the Top Scorer!!!", True, (255, 255, 255))
    screen.blit(congrats, (50, 350))

def gameover():
    overtext=over_font.render("GAME OVER",True,(255,0,0))
    screen.blit(overtext, (200, 250))
    global score,highestscore,flag
    if score>highestscore:
        highestscore=score
        f.write(str(highestscore))
        flag=1

def player(x, y):
    screen.blit(playerimg, (x, y))


def enemy(x, y):
    screen.blit(enemyimg, (x, y))


def creator():
    creator = cfont.render("By Shrutik Gumate",True, (255, 255, 255))
    screen.blit(creator,(650,560))

def fire_bullet(x, y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletimg, (x + 16, y + 10))


def isCollision(enemyX, enemyY, bulletX, bulletY):
    distance = math.sqrt(math.pow((enemyX - bulletX), 2) + math.pow((enemyY - bulletY), 2))
    if distance < 25: return True
    return False




running = True
while running:

    screen.fill((0, 0, 0))
    screen.blit(background, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                PchangeX -= playerspeed

            if event.key == pygame.K_RIGHT:
                PchangeX += playerspeed


            if event.key == pygame.K_SPACE:
                if bullet_state == "ready":
                    bulletX = playerX
                    fire_bullet(bulletX, bulletY)

        if event.type == pygame.KEYUP:
            # checks whether its that key or not
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT or event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                PchangeX = 0
                PchangeY = 0


    playerX += PchangeX

    if playerX <= 0:
        playerX = 0
    elif playerX >= 736:
        playerX = 736



    enemyX += EchangeX


    if enemyX <= 0:
        EchangeX = enemyspeed
        enemyY += EchangeY
    elif enemyX >= 768:
        EchangeX = -1*(enemyspeed)
        enemyY += EchangeY
    if enemyY>460:
        enemyY=2000
        gameover()

    collision = isCollision(enemyX, enemyY, bulletX, bulletY)
    if collision:
        bullet_state = "ready"
        bulletY = 480
        score += 1
        enemyspeed += 1
        print(score)
        enemyX = random.randint(0, 768)
        enemyY = random.randint(0, 150)

    if bulletY <= 0:
        bulletY = playerY
        bullet_state = "ready"

    enemy(enemyX, enemyY)

    if bullet_state == "fire":
        fire_bullet(bulletX, bulletY)
        bulletY -= BchangeY


    player(playerX, playerY)
    showscore(textX,textY)
    highscore()
    if flag==1:
        congrats()
    creator()

    pygame.display.update()

f.close()